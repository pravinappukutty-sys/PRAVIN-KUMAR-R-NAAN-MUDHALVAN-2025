import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Github, Globe, Linkedin, Mail, Phone, FileDown, ExternalLink, Briefcase, GraduationCap, Award, Settings } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// ----------------------
// Sample Data (edit me)
// ----------------------
const PROFILE = {
  name: "Your Name",
  role: "Full‑Stack Developer",
  tagline: "I build scalable web apps and delightful user experiences.",
  email: "you@example.com",
  phone: "+91-98765-43210",
  location: "Chennai, IN",
  resumeUrl: "#", // replace with a real link
  socials: {
    github: "https://github.com/yourname",
    linkedin: "https://linkedin.com/in/yourname",
    portfolio: "#",
  },
};

const SKILLS = [
  { name: "JavaScript", level: 90, category: "Web" },
  { name: "TypeScript", level: 85, category: "Web" },
  { name: "React", level: 90, category: "Web" },
  { name: "Next.js", level: 80, category: "Web" },
  { name: "Node.js", level: 88, category: "Backend" },
  { name: "Express", level: 82, category: "Backend" },
  { name: "Python", level: 84, category: "Data" },
  { name: "SQL", level: 78, category: "Data" },
  { name: "Tailwind CSS", level: 86, category: "Web" },
  { name: "Docker", level: 70, category: "DevOps" },
];

const PROJECTS = [
  {
    id: 1,
    title: "Smart Jobs — AI Resume Matcher",
    year: 2025,
    type: "Web",
    stack: ["Next.js", "OpenAI", "Tailwind"],
    description:
      "Ranks resumes against job descriptions using embeddings and highlights skill gaps.",
    live: "#",
    source: "#",
  },
  {
    id: 2,
    title: "CampusKart — College Marketplace",
    year: 2024,
    type: "Mobile",
    stack: ["React Native", "Firebase", "Stripe"],
    description:
      "Peer‑to‑peer marketplace for students to buy/sell books and essentials.",
    live: "#",
    source: "#",
  },
  {
    id: 3,
    title: "VizBoard — Analytics Dashboard",
    year: 2023,
    type: "Data",
    stack: ["Python", "FastAPI", "Postgres", "Recharts"],
    description:
      "Modular KPI dashboard with role‑based access and scheduled reports.",
    live: "#",
    source: "#",
  },
  {
    id: 4,
    title: "Portfolio 3D — Interactive Site",
    year: 2022,
    type: "Web",
    stack: ["React", "Three.js"],
    description:
      "Interactive 3D portfolio with smooth page transitions and GLSL effects.",
    live: "#",
    source: "#",
  },
];

const EXPERIENCE = [
  {
    title: "Software Engineer",
    org: "Acme Corp",
    period: "2023 — Present",
    bullets: [
      "Built micro‑services powering 1M+ monthly users.",
      "Reduced API latency by 32% through caching and profiling.",
    ],
  },
  {
    title: "SDE Intern",
    org: "Tech Labs",
    period: "2022 — 2023",
    bullets: [
      "Implemented CI/CD pipelines and containerized services.",
      "Wrote integration tests and improved coverage to 85%.",
    ],
  },
];

const EDUCATION = [
  {
    title: "B.Tech in Computer Science",
    org: "Your University",
    period: "2019 — 2023",
  },
];

const CERTS = [
  { title: "AWS Certified Cloud Practitioner", org: "Amazon Web Services", year: 2024 },
  { title: "Google Data Analytics", org: "Coursera", year: 2023 },
];

// ----------------------
// Utility
// ----------------------
const fade = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

function SectionTitle({ icon: Icon, title, subtitle }) {
  return (
    <div className="flex items-start justify-between">
      <div>
        <div className="flex items-center gap-2">
          <Icon className="h-5 w-5" />
          <h2 className="text-xl sm:text-2xl font-semibold">{title}</h2>
        </div>
        {subtitle && (
          <p className="text-sm text-muted-foreground mt-1">{subtitle}</p>
        )}
      </div>
    </div>
  );
}

function ProjectCard({ project }) {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg">{project.title}</CardTitle>
        <div className="flex flex-wrap gap-2 mt-2">
          {project.stack.map((s) => (
            <Badge variant="secondary" key={s}>{s}</Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="rounded-2xl border aspect-[16/9] grid place-items-center text-sm text-muted-foreground">
          Project Preview
        </div>
        <p className="text-sm leading-relaxed">{project.description}</p>
        <div className="flex gap-2">
          <Button asChild variant="default" size="sm">
            <a href={project.live} target="_blank" rel="noreferrer">
              <Globe className="h-4 w-4 mr-1" /> Live Demo
            </a>
          </Button>
          <Button asChild variant="outline" size="sm">
            <a href={project.source} target="_blank" rel="noreferrer">
              <Github className="h-4 w-4 mr-1" /> Source
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function PortfolioApp() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50 text-slate-900">
      <h1 className="text-3xl font-bold p-6 text-center">
        Smart Career Portfolio — A Digital Showcase of Skills and Projects
      </h1>
    </div>
  );
}
